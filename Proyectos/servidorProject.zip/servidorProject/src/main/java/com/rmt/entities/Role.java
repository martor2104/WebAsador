package com.rmt.entities;

public enum Role {
	ROLE_USER,
    ROLE_ADMIN
}
