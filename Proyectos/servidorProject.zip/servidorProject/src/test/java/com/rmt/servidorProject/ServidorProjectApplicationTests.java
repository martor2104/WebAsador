package com.rmt.servidorProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
